-- Calculate the percentage contribution of
--  each pizza type to total revenue.

select category , round((sum(quantity * price) / (SELECT 
    ROUND(SUM(quantity * price),2) AS total_revenue
FROM
    order_details
        JOIN
    pizzas ON pizzas.pizza_id = order_details.pizza_id))*100,2) as Revenue from 
pizza_types join pizzas on 
pizza_types.pizza_type_id = pizzas.pizza_type_id
join order_details on
order_details.pizza_id = pizzas.pizza_id
group by category 
order by Revenue desc;


-- Analyze the cumulative revenue generated over time.


select order_date, sum(revenue) over (order by order_date)
as cum_revenue
from
(select order_date,sum(quantity*price) as Revenue
from order_details join pizzas 
on order_details.pizza_id = pizzas.pizza_id
join orders 
on orders.order_id = order_details.order_id
group by order_date) as sales;



-- Determine the top 3 most ordered pizza types based on revenue
--  for each pizza category

select name,Revenue from
(select name,category, Revenue,
rank() over(partition by category order by Revenue desc) as rn
from
(select name,category, sum(quantity*price) as Revenue
from pizza_types join pizzas
on pizza_types.pizza_type_id = pizzas.pizza_type_id
join order_details 
on order_details.pizza_id = pizzas.pizza_id
group by name,category) as A) as B
where rn <=3;