-- Join the necessary tables to find the total quantity of each pizza category ordered.

select category,sum(quantity) as Quantity 
from pizza_types join pizzas
on pizza_types.pizza_type_id = pizzas.pizza_type_id
join order_details on pizzas.pizza_id = order_details.pizza_id
group by category 
order by Quantity desc;

-- Determine the distribution of orders by hour of the day.

select hour(order_time) as Order_Hourly, count(order_id) as order_count from orders
group by Order_Hourly;


-- Join relevant tables to find the category-wise distribution of pizzas.

select category as Pizza_Category,count(pizza_type_id) as Count_Pizza from pizza_types
group by Pizza_category;


-- Group the orders by date and calculate the average number of pizzas ordered per day.

select round(avg(Quantity),2) from 
(select order_date , sum(quantity) as Quantity
from order_details join orders
on order_details.order_id = orders.order_id
group by (order_date)) as data;


-- Determine the top 3 most ordered pizza types based on revenue.

select name,sum(quantity*price) as Revenue from order_details
join pizzas on
pizzas.pizza_id = order_details.pizza_id
join pizza_types on
pizza_types.pizza_type_id = pizzas.pizza_type_id
group by name
order by Revenue desc limit 3;