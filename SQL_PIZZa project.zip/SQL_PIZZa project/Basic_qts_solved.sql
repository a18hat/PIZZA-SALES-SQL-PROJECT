-- Questions 

-- Retrieve the total number of orders placed.

select count(order_id) from orders;

-- Calculate the total revenue generated from pizza sales

SELECT 
    ROUND(SUM(quantity * price),2) AS total_revenue
FROM
    order_details
        JOIN
    pizzas ON pizzas.pizza_id = order_details.pizza_id; 
    

-- Identify the highest-priced pizza.

select name,price from pizza_types join pizzas
on pizza_types.pizza_type_id = pizzas.pizza_type_id
order by price desc limit 1;


-- Identify the most common pizza size ordered.

select count(order_details_id) as Order_count, size 
from order_details join pizzas
on order_details.pizza_id = pizzas.pizza_id
group by size
order by Order_count desc ;



-- List the top 5 most ordered pizza types along with their quantities. 

SELECT 
    name, SUM(quantity) AS Quantity
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
        JOIN
    order_details ON order_details.pizza_id = pizzas.pizza_id
GROUP BY name
ORDER BY Quantity DESC
LIMIT 5;